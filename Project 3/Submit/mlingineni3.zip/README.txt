Milind Lingineni
CS 4641 - Summer 2017
Reinforcement Learning

!!! Note that the classpath separator is platform dependent so use ":" for *nix and ";" for Windows. !!!

To run the GridWorld Markov Decision Process (MDP):
java -cp "lib/*:target/classes" Project3.GridWorldRun

To run the Block Dude MDP:
java -cp "lib/*:target/classes" Project3.BDRun

You need to have Java 6 or higher to run this program.

Attributions:
James MacGlashan. BURLAP. http://burlap.cs.brown.edu/